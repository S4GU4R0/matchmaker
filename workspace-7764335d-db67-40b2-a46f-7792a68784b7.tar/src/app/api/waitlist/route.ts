import { Client } from '@notionhq/client'
import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const notion = new Client({
  auth: process.env.NOTION_API_KEY,
})

const DATABASE_ID = process.env.NOTION_DATABASE_ID

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email, interest, storage } = body

    if (!email) {
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Please enter a valid email address' },
        { status: 400 }
      )
    }

    // Handle email-only storage (local database)
    if (storage === 'email') {
      // Check if email already exists in local database
      const existing = await db.waitlistEntry.findUnique({
        where: { email },
      })

      if (existing) {
        return NextResponse.json(
          { error: 'This email is already on the waitlist' },
          { status: 400 }
        )
      }

      // Store locally (private, not in Notion)
      await db.waitlistEntry.create({
        data: {
          email,
          interest: interest || null,
          storageType: 'email',
        },
      })

      return NextResponse.json({ success: true })
    }

    // Handle Notion storage
    if (!DATABASE_ID || !process.env.NOTION_API_KEY) {
      console.error('Notion credentials not configured')
      return NextResponse.json(
        { error: 'Notion storage not configured. Please contact the administrator.' },
        { status: 500 }
      )
    }

    // Check if email already exists in Notion
    const existingEntries = await notion.databases.query({
      database_id: DATABASE_ID,
      filter: {
        property: 'Email',
        title: {
          equals: email,
        },
      },
    })

    if (existingEntries.results.length > 0) {
      return NextResponse.json(
        { error: 'This email is already on the waitlist' },
        { status: 400 }
      )
    }

    // Add to Notion database
    await notion.pages.create({
      parent: {
        database_id: DATABASE_ID,
      },
      properties: {
        Email: {
          title: [
            {
              text: {
                content: email,
              },
            },
          ],
        },
        Interest: {
          rich_text: [
            {
              text: {
                content: interest || '',
              },
            },
          ],
        },
        Status: {
          select: {
            name: 'Waitlist',
          },
        },
        'Signed Up': {
          date: {
            start: new Date().toISOString(),
          },
        },
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error adding to waitlist:', error)
    
    if (error instanceof Error && error.message.includes('validation_error')) {
      return NextResponse.json(
        { error: 'Database configuration error. Please check Notion database properties.' },
        { status: 500 }
      )
    }
    
    return NextResponse.json(
      { error: 'Failed to join waitlist. Please try again.' },
      { status: 500 }
    )
  }
}
