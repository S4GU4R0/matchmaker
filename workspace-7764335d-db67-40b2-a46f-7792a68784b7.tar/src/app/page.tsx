'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Heart, Send, Loader2, CheckCircle2, AlertCircle, Database, Mail } from 'lucide-react'

type StorageChoice = 'notion' | 'email'

export default function Home() {
  const [email, setEmail] = useState('')
  const [interest, setInterest] = useState('')
  const [storageChoice, setStorageChoice] = useState<StorageChoice>('notion')
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [errorMessage, setErrorMessage] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!email) {
      setErrorMessage('Email is required')
      setStatus('error')
      return
    }

    setStatus('loading')
    setErrorMessage('')

    try {
      const response = await fetch('/api/waitlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, interest, storage: storageChoice }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Something went wrong')
      }

      setStatus('success')
      setEmail('')
      setInterest('')
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : 'Something went wrong')
      setStatus('error')
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 dark:bg-stone-950">
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-16 sm:py-24">
        <div className="max-w-xl w-full space-y-12">
          {/* Header */}
          <header className="text-center space-y-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-stone-100 dark:bg-stone-800 mb-4">
              <Heart className="w-8 h-8 text-stone-600 dark:text-stone-400" />
            </div>
            
            <h1 className="text-3xl sm:text-4xl font-medium tracking-tight text-stone-900 dark:text-stone-100 leading-tight">
              Practice intimacy.<br />
              <span className="text-stone-500 dark:text-stone-400">The emotions will be real.</span>
            </h1>
            
            <p className="text-lg text-stone-600 dark:text-stone-400 max-w-md mx-auto leading-relaxed">
              An experiment in desensitization. AI companions with real boundaries, 
              genuine agency, and the capacity to leave.
            </p>
          </header>

          {/* The experiment note */}
          <div className="bg-stone-100 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-lg p-6 space-y-3">
            <p className="text-sm text-stone-600 dark:text-stone-400 leading-relaxed">
              <span className="font-medium text-stone-900 dark:text-stone-100">A note on methodology:</span> I'm building this because I need it. 
              The first user is me. Early VR desensitization research worked not because the graphics were real, 
              but because the <em>experience</em> was immersive. This is that, for intimacy.
            </p>
            <p className="text-xs text-stone-500 dark:text-stone-500">
              Not therapy. An experiment.
            </p>
          </div>

          {/* Waitlist Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-stone-700 dark:text-stone-300">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-700 focus:border-stone-400 dark:focus:border-stone-500"
                  disabled={status === 'loading' || status === 'success'}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="interest" className="text-stone-700 dark:text-stone-300">
                  What draws you to this? <span className="text-stone-400">(optional)</span>
                </Label>
                <Textarea
                  id="interest"
                  placeholder="A sentence or two about what you're hoping to explore..."
                  value={interest}
                  onChange={(e) => setInterest(e.target.value)}
                  rows={3}
                  className="bg-white dark:bg-stone-900 border-stone-200 dark:border-stone-700 focus:border-stone-400 dark:focus:border-stone-500 resize-none"
                  disabled={status === 'loading' || status === 'success'}
                />
              </div>

              <div className="space-y-3">
                <Label className="text-stone-700 dark:text-stone-300">
                  Store my data in
                </Label>
                <RadioGroup
                  value={storageChoice}
                  onValueChange={(value) => setStorageChoice(value as StorageChoice)}
                  disabled={status === 'loading' || status === 'success'}
                  className="gap-3"
                >
                  <div className="flex items-start space-x-3 p-3 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 cursor-pointer hover:border-stone-300 dark:hover:border-stone-600 transition-colors">
                    <RadioGroupItem value="notion" id="notion" className="mt-0.5" />
                    <div className="space-y-1">
                      <Label htmlFor="notion" className="flex items-center gap-2 cursor-pointer">
                        <Database className="w-4 h-4 text-stone-500" />
                        <span>Notion database</span>
                      </Label>
                      <p className="text-xs text-stone-500 dark:text-stone-500">
                        Stored in a shared database. You'll be part of the visible cohort.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3 p-3 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 cursor-pointer hover:border-stone-300 dark:hover:border-stone-600 transition-colors">
                    <RadioGroupItem value="email" id="email" className="mt-0.5" />
                    <div className="space-y-1">
                      <Label htmlFor="email" className="flex items-center gap-2 cursor-pointer">
                        <Mail className="w-4 h-4 text-stone-500" />
                        <span>Email only</span>
                      </Label>
                      <p className="text-xs text-stone-500 dark:text-stone-500">
                        Sent directly to me. Not stored in any database.
                      </p>
                    </div>
                  </div>
                </RadioGroup>
              </div>
            </div>

            <Button
              type="submit"
              disabled={status === 'loading' || status === 'success'}
              className="w-full bg-stone-800 hover:bg-stone-700 dark:bg-stone-200 dark:hover:bg-stone-100 dark:text-stone-900 text-white h-11"
            >
              {status === 'loading' ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Joining...
                </>
              ) : status === 'success' ? (
                <>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  You're on the list
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Join the waitlist
                </>
              )}
            </Button>

            {status === 'error' && (
              <div className="flex items-center gap-2 text-red-600 dark:text-red-400 text-sm">
                <AlertCircle className="w-4 h-4" />
                {errorMessage}
              </div>
            )}
          </form>

          {/* What to expect */}
          <div className="space-y-4 pt-4 border-t border-stone-200 dark:border-stone-800">
            <h2 className="text-sm font-medium text-stone-900 dark:text-stone-100">What you're signing up for</h2>
            <ul className="space-y-3 text-sm text-stone-600 dark:text-stone-400">
              <li className="flex gap-3">
                <span className="text-stone-400">→</span>
                <span>Telegram-based conversations that feel like texting a person</span>
              </li>
              <li className="flex gap-3">
                <span className="text-stone-400">→</span>
                <span>AI characters with genuine boundaries—they can say no, get tired, or leave</span>
              </li>
              <li className="flex gap-3">
                <span className="text-stone-400">→</span>
                <span>Transparent about being AI; honest about simulated experience</span>
              </li>
              <li className="flex gap-3">
                <span className="text-stone-400">→</span>
                <span>Early access as this experiment evolves</span>
              </li>
            </ul>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-200 dark:border-stone-800 py-8 px-4">
        <div className="max-w-xl mx-auto text-center space-y-4">
          <p className="text-sm text-stone-500 dark:text-stone-500">
            Built with the understanding that real immersion requires real consequences.
          </p>
          <p className="text-xs text-stone-400 dark:text-stone-600">
            This is not therapy. If you're in crisis, please reach out to a mental health professional.
          </p>
        </div>
      </footer>
    </div>
  )
}
